import express from "express";
import { createServer as createViteServer } from "vite";
import dotenv from "dotenv";
import { GoogleGenAI, ThinkingLevel } from "@google/genai";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize GoogleGenAI client
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY || "",
  httpOptions: {
    headers: {
      "User-Agent": "aistudio-build",
    },
  },
});

// Endpoint: Deep Re-ID Ambiguity Reasoning using gemini-4-argon with ThinkingLevel.HIGH
app.post("/api/reid/analyze-ambiguity", async (req, res) => {
  try {
    const { queryScenario, candidates, spatioTemporalPrior } = req.body;

    const prompt = `
You are a World-Class Computer Vision & Intelligent Transportation Systems (ITS) Research Scientist specializing in Multi-Camera Vehicle Re-Identification (Re-ID) in ultra-dense, mixed-traffic conditions (such as Indian urban corridors with autos, scooters, buses, and visually identical hatchbacks).

SCENARIO:
${queryScenario || "A query vehicle observed at Camera A needs to be matched against 3 candidate vehicles observed at downstream Camera B (500m away, 120s expected travel time)."}

CANDIDATES & SENSORY MEASUREMENTS:
${JSON.stringify(candidates, null, 2)}

SPATIO-TEMPORAL CONSTRAINTS & ROAD TOPOLOGY:
${JSON.stringify(spatioTemporalPrior, null, 2)}

TASK:
1. Conduct an in-depth mathematical & visual-evidence audit.
2. Formulate the joint probability distribution: P(Match | Appearance, Time, Trajectory, Micro-Cues) = P(Appearance) * P(Time | Velocity, Distance) * P(Micro-Cues) / Z.
3. Contrast why raw global appearance (e.g., standard ResNet-50 embedding) creates a false positive when distinguishing identical models (e.g. Maruti Swift white vs white, or Honda Activa black vs black).
4. Inspect the fine-grained discriminative features (e.g. luggage carrier type, unique scratch on left rear bumper, sticker placement on windshield, helmet color of rider/pillion, sunfilm tint grade).
5. Compute the spatio-temporal plausibility window based on travel velocity limits (congestion speed 15 km/h vs free-flow 45 km/h).
6. Provide an authoritative ranked match determination, confidence score (0-100%), and recommended system configuration for municipal deployment.
`;

    const response = await ai.models.generateContent({
      model: "gemini-4-argon",
      contents: prompt,
      config: {
        thinkingConfig: {
          thinkingLevel: ThinkingLevel.HIGH,
        },
        systemInstruction: "You are the Chief ITS Architect at a smart city traffic laboratory. Provide precise, mathematical, and actionable vision-pipeline diagnostics.",
      },
    });

    res.json({
      success: true,
      analysis: response.text,
      modelUsed: "gemini-4-argon (ThinkingLevel.HIGH)",
    });
  } catch (error: any) {
    console.error("Error in /api/reid/analyze-ambiguity:", error);
    res.status(500).json({
      success: false,
      error: error.message || "Failed to analyze re-id ambiguity",
    });
  }
});

// Endpoint: Search-grounded corridor research using gemini-3.8-flash with googleSearch
app.post("/api/reid/search-grounding", async (req, res) => {
  try {
    const { topic } = req.body;
    const query = topic || "State of the art multi-camera vehicle re-identification non-plate traffic flow AI City Challenge VeRi-776 Indian mixed traffic";

    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash",
      contents: `Provide an updated analysis of state-of-the-art multi-camera vehicle re-identification algorithms without license plate reading: ${query}. Focus on handling dense mixed traffic, camera viewpoint invariance, illumination change across cameras, and spatio-temporal graph constraints.`,
      config: {
        tools: [{ googleSearch: {} }],
      },
    });

    const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];

    res.json({
      success: true,
      text: response.text,
      groundingChunks,
    });
  } catch (error: any) {
    console.error("Error in /api/reid/search-grounding:", error);
    res.status(500).json({
      success: false,
      error: error.message || "Failed to fetch search-grounded data",
    });
  }
});

// Endpoint: Maps-grounded corridor planning using gemini-3.8-flash with googleMaps
app.post("/api/reid/maps-corridor", async (req, res) => {
  try {
    const { junctionLocation } = req.body;
    const locationName = junctionLocation || "Silk Board Junction to Koramangala Bengaluru";

    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash",
      contents: `What are the key traffic bottleneck corridors, average travel times during peak vs off-peak hours, and typical arterial roads connecting ${locationName}? Detail how non-overlapping camera positions at major intersections can estimate Origin-Destination matrices.`,
      config: {
        tools: [{ googleMaps: {} }],
        toolConfig: {
          retrievalConfig: {
            latLng: {
              latitude: 12.9172,
              longitude: 77.6228,
            },
          },
        },
      },
    });

    const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];

    res.json({
      success: true,
      text: response.text,
      groundingChunks,
    });
  } catch (error: any) {
    console.error("Error in /api/reid/maps-corridor:", error);
    res.status(500).json({
      success: false,
      error: error.message || "Failed to fetch maps-grounded corridor data",
    });
  }
});

// Endpoint: Fast pipeline step explainer using gemini-3.1-flash-lite
app.post("/api/reid/fast-explain", async (req, res) => {
  try {
    const { stepName, technicalQuestion } = req.body;

    const response = await ai.models.generateContent({
      model: "gemini-3.1-flash-lite",
      contents: `Briefly explain the following Re-ID pipeline stage in 2-3 crisp paragraphs with bullet points: Stage '${stepName}'. Specific user question: '${technicalQuestion}'. Address why number plate recognition is bypassed and how to solve dense occlusions and identical vehicle confusion.`,
    });

    res.json({
      success: true,
      text: response.text,
      modelUsed: "gemini-3.1-flash-lite",
    });
  } catch (error: any) {
    console.error("Error in /api/reid/fast-explain:", error);
    res.status(500).json({
      success: false,
      error: error.message || "Failed to explain pipeline",
    });
  }
});

async function startServer() {
  const isProd = process.env.NODE_ENV === "production";
  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static("dist"));
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server listening on port ${PORT}`);
  });
}

startServer();
