import {
  SimulatedVehicle,
  VehicleType,
  MicroFeatures,
  CameraNode,
  ReIdMatchResult,
  OriginDestinationMatrix,
} from "../types/reid";

// Camera Network Topology
export const CAMERA_NODES: CameraNode[] = [
  {
    id: "CAM_A",
    name: "Camera 01: Silk Board North Entry",
    junctionTitle: "Hosur Road Junction Approach",
    worldPos: [-45, 14, -8],
    viewDirection: [0.7, -0.6, 0.4],
    fov: 48,
    roadDistanceToNextKm: 0.9,
    typicalTransitSeconds: { min: 35, max: 95, mean: 55, stdDev: 12 },
  },
  {
    id: "CAM_B",
    name: "Camera 02: Koramangala 100ft Flyover",
    junctionTitle: "Intermediate Arterial Link",
    worldPos: [0, 14, 8],
    viewDirection: [-0.6, -0.6, -0.5],
    fov: 50,
    roadDistanceToNextKm: 1.1,
    typicalTransitSeconds: { min: 45, max: 120, mean: 70, stdDev: 15 },
  },
  {
    id: "CAM_C",
    name: "Camera 03: HSR Layout Sector 1 Gate",
    junctionTitle: "Ring Road Interchange Exit",
    worldPos: [45, 14, -8],
    viewDirection: [-0.7, -0.6, 0.4],
    fov: 48,
    roadDistanceToNextKm: 0,
    typicalTransitSeconds: { min: 0, max: 0, mean: 0, stdDev: 0 },
  },
];

// Helper: Cosine similarity between two unit-normalized embedding vectors
export function cosineSimilarity(vecA: number[], vecB: number[]): number {
  if (!vecA || !vecB || vecA.length !== vecB.length) return 0;
  let dot = 0;
  let normA = 0;
  let normB = 0;
  for (let i = 0; i < vecA.length; i++) {
    dot += vecA[i] * vecB[i];
    normA += vecA[i] * vecA[i];
    normB += vecB[i] * vecB[i];
  }
  if (normA === 0 || normB === 0) return 0;
  const sim = dot / (Math.sqrt(normA) * Math.sqrt(normB));
  return Math.max(0, Math.min(1, (sim + 1) / 2)); // map [-1, 1] to [0, 1]
}

// Spatio-Temporal travel time probability density: P(Δt | distance, congestion)
export function calculateSpatioTemporalScore(
  deltaSeconds: number,
  params: { min: number; max: number; mean: number; stdDev: number }
): number {
  // Physical impossibilities: speed exceeding corridor maximum or vehicle stopping indefinitely
  if (deltaSeconds < params.min * 0.6) {
    // Requires unrealistically fast speed (e.g. 150 km/h in urban congestion)
    return 0.01;
  }
  if (deltaSeconds > params.max * 2.2) {
    // Requires pulling over or deviating from corridor
    return 0.05;
  }

  // Gaussian PDF normalized
  const z = (deltaSeconds - params.mean) / (params.stdDev || 10);
  const prob = Math.exp(-0.5 * z * z);
  return Math.max(0.02, Math.min(0.99, prob));
}

// Micro-feature comparison (the secret weapon against identical vehicles!)
export function calculateMicroFeatureScore(
  featA: MicroFeatures,
  featB: MicroFeatures,
  type: VehicleType
): number {
  let score = 0.5; // Neutral baseline
  let checks = 0;

  if (type === "two_wheeler") {
    checks++;
    if (featA.helmetColor && featB.helmetColor) {
      if (featA.helmetColor === featB.helmetColor) score += 0.35;
      else score -= 0.45; // High penalty for different helmet colors!
    }
  }

  if (type === "hatchback" || type === "truck") {
    checks++;
    if (featA.roofRack === featB.roofRack) score += 0.15;
    else score -= 0.35; // Roof rack presence is highly discriminative

    checks++;
    if (featA.bumperScratch === featB.bumperScratch && featA.bumperScratch) {
      score += 0.3; // Unique scratch matching
    } else if (featA.bumperScratch !== featB.bumperScratch) {
      score -= 0.15;
    }

    checks++;
    if (featA.windshieldSticker === featB.windshieldSticker && featA.windshieldSticker) {
      score += 0.25; // Decal / fastag / permit sticker match
    }

    if (featA.sunfilmTint && featB.sunfilmTint) {
      if (featA.sunfilmTint === featB.sunfilmTint) score += 0.1;
      else score -= 0.15;
    }
  }

  if (type === "auto_rickshaw") {
    checks++;
    if (featA.cargoType === featB.cargoType) score += 0.2;
    if (featA.windshieldSticker === featB.windshieldSticker) score += 0.2;
  }

  return Math.max(0, Math.min(1, score));
}

// Generate an authentic 16-d appearance vector for vehicle
export function generateAppearanceVector(
  type: VehicleType,
  primaryColorHex: string,
  microFeatures: MicroFeatures,
  noiseVariance: number = 0.05
): number[] {
  const vec = new Array(16).fill(0);
  // Encode vehicle type in dims 0-4
  const typeIndex = ["two_wheeler", "auto_rickshaw", "hatchback", "bus", "truck"].indexOf(type);
  if (typeIndex >= 0) vec[typeIndex] = 1.0;

  // Encode primary color in dims 5-7 (RGB normalized)
  const hex = primaryColorHex.replace("#", "");
  const r = parseInt(hex.substring(0, 2), 16) / 255;
  const g = parseInt(hex.substring(2, 4), 16) / 255;
  const b = parseInt(hex.substring(4, 6), 16) / 255;
  vec[5] = r;
  vec[6] = g;
  vec[7] = b;

  // Encode micro-features in dims 8-12
  vec[8] = microFeatures.roofRack ? 1.0 : 0.0;
  vec[9] = microFeatures.bumperScratch ? 1.0 : 0.0;
  vec[10] = microFeatures.windshieldSticker ? 1.0 : 0.0;
  const helmetMap: Record<string, number> = { black: 0.2, white: 0.5, red: 0.8, yellow: 1.0, none: 0.0 };
  vec[11] = helmetMap[microFeatures.helmetColor || "none"] || 0;
  vec[12] = microFeatures.sunfilmTint === "dark" ? 0.9 : microFeatures.sunfilmTint === "mild" ? 0.5 : 0.1;

  // Add subtle sensory noise (simulating camera exposure, viewpoint angle distortion)
  for (let i = 0; i < 16; i++) {
    vec[i] += (Math.random() - 0.5) * noiseVariance;
  }

  // Normalize to unit length
  let norm = 0;
  for (let v of vec) norm += v * v;
  norm = Math.sqrt(norm) || 1;
  return vec.map((v) => v / norm);
}

// Indian Traffic Colors & Variants
const INDIAN_VEHICLE_VARIANTS: {
  type: VehicleType;
  colorName: string;
  primaryHex: string;
  secondaryHex: string;
}[] = [
  // High prevalence of identical white hatchbacks
  { type: "hatchback", colorName: "Arctic White", primaryHex: "#f0f2f5", secondaryHex: "#1e293b" },
  { type: "hatchback", colorName: "Silky Silver", primaryHex: "#cbd5e1", secondaryHex: "#334155" },
  { type: "hatchback", colorName: "Pearl White", primaryHex: "#ffffff", secondaryHex: "#0f172a" },
  { type: "hatchback", colorName: "Magma Grey", primaryHex: "#475569", secondaryHex: "#0f172a" },
  { type: "hatchback", colorName: "Blazing Red", primaryHex: "#dc2626", secondaryHex: "#111827" },

  // Auto-rickshaws
  { type: "auto_rickshaw", colorName: "CNG Green/Yellow", primaryHex: "#15803d", secondaryHex: "#eab308" },
  { type: "auto_rickshaw", colorName: "Classic Yellow/Black", primaryHex: "#eab308", secondaryHex: "#18181b" },
  { type: "auto_rickshaw", colorName: "Electric Teal", primaryHex: "#0d9488", secondaryHex: "#eab308" },

  // Two-wheelers
  { type: "two_wheeler", colorName: "Gloss Black Scooter", primaryHex: "#18181b", secondaryHex: "#94a3b8" },
  { type: "two_wheeler", colorName: "Pearl White Activa", primaryHex: "#f8fafc", secondaryHex: "#334155" },
  { type: "two_wheeler", colorName: "Racing Blue Bike", primaryHex: "#2563eb", secondaryHex: "#0f172a" },
  { type: "two_wheeler", colorName: "Matte Red Commuter", primaryHex: "#ef4444", secondaryHex: "#1e293b" },

  // Buses
  { type: "bus", colorName: "BMTC Transit Blue", primaryHex: "#0284c7", secondaryHex: "#f8fafc" },
  { type: "bus", colorName: "Eco Green Transit", primaryHex: "#16a34a", secondaryHex: "#fef08a" },

  // Light Commercial Vehicles (Tata Ace)
  { type: "truck", colorName: "Commercial White LCV", primaryHex: "#f1f5f9", secondaryHex: "#334155" },
  { type: "truck", colorName: "Cargo Silver Pickup", primaryHex: "#94a3b8", secondaryHex: "#1e293b" },
];

export function createRandomVehicle(idIndex: number, forcedType?: VehicleType, forcedVariant?: any): SimulatedVehicle {
  const variant =
    forcedVariant ||
    (forcedType
      ? INDIAN_VEHICLE_VARIANTS.find((v) => v.type === forcedType) || INDIAN_VEHICLE_VARIANTS[0]
      : INDIAN_VEHICLE_VARIANTS[Math.floor(Math.random() * INDIAN_VEHICLE_VARIANTS.length)]);

  const helmetColors: MicroFeatures["helmetColor"][] = ["black", "white", "red", "yellow"];
  const microFeatures: MicroFeatures = {
    helmetColor: variant.type === "two_wheeler" ? helmetColors[Math.floor(Math.random() * helmetColors.length)] : "none",
    roofRack: variant.type === "hatchback" || variant.type === "truck" ? Math.random() > 0.65 : false,
    bumperScratch: Math.random() > 0.6,
    windshieldSticker: Math.random() > 0.5,
    cargoType: variant.type === "truck" ? (Math.random() > 0.5 ? "tarpaulin" : "crates") : "none",
    sunfilmTint: Math.random() > 0.7 ? "dark" : Math.random() > 0.4 ? "mild" : "clear",
  };

  const trueEmbedding = generateAppearanceVector(variant.type, variant.primaryHex, microFeatures, 0.02);

  // Road lane: -1 (fast lane), 0 (middle lane), 1 (slow/service lane)
  const lane = Math.floor(Math.random() * 3) - 1;
  const startX = -65 - idIndex * 8;
  const startZ = lane * 2.4;

  return {
    id: `veh_${idIndex}_${Date.now().toString(36)}`,
    globalId: `GID-${String(idIndex).padStart(4, "0")}`,
    type: variant.type,
    colorName: variant.colorName,
    primaryColorHex: variant.primaryHex,
    secondaryColorHex: variant.secondaryHex,
    microFeatures,
    trueEmbedding,
    originCamera: "CAM_A",
    destinationCamera: Math.random() > 0.25 ? "CAM_C" : "CAM_B",
    routeProgress: 0,
    currentPosition: [startX, 0, startZ],
    velocity: 8 + Math.random() * 4, // units per second in 3D scene
    currentLane: lane,
    sightings: [],
    isActive: true,
  };
}

// Bayesian Multi-Cue Match Evaluation
// Module scope counter for globally unique match event IDs
let _globalMatchCounter = 0;

export function evaluateCandidateMatch(
  queryVehicle: SimulatedVehicle,
  candidateVehicle: SimulatedVehicle,
  cameraA: CameraNode,
  cameraB: CameraNode,
  timeA: number,
  timeB: number,
  weights = { appearance: 0.45, spatioTemporal: 0.35, microFeatures: 0.2 }
): ReIdMatchResult {
  const deltaSeconds = Math.max(1, timeB - timeA);
  const transitParams = cameraA.typicalTransitSeconds;

  // 1. Appearance Cosine Similarity
  const appSim = cosineSimilarity(queryVehicle.trueEmbedding, candidateVehicle.trueEmbedding);

  // 2. Spatio-Temporal Probability
  const stProb = calculateSpatioTemporalScore(deltaSeconds, transitParams);

  // 3. Fine-Grained Micro-Feature Score
  const microScore = calculateMicroFeatureScore(
    queryVehicle.microFeatures,
    candidateVehicle.microFeatures,
    queryVehicle.type
  );

  // Combined weighted posterior score
  const combined =
    weights.appearance * appSim +
    weights.spatioTemporal * stProb +
    weights.microFeatures * microScore;

  const isGroundTruthMatch = queryVehicle.globalId === candidateVehicle.globalId;

  let decision: "TRUE_MATCH" | "AMBIGUOUS" | "FALSE_ALARM" = "FALSE_ALARM";
  if (combined >= 0.78) {
    decision = "TRUE_MATCH";
  } else if (combined >= 0.58) {
    decision = "AMBIGUOUS";
  }

  // Construct explanatory diagnostic rationale
  let reasoning = "";
  if (isGroundTruthMatch) {
    reasoning = `High visual confidence (${(appSim * 100).toFixed(1)}%) + Spatio-temporal window aligned (${deltaSeconds}s vs expected ${transitParams.mean}s). Micro-cues confirm identity.`;
  } else {
    if (appSim > 0.8) {
      reasoning = `Deceptive visual similarity (${(appSim * 100).toFixed(1)}%) - identically colored vehicle! Disambiguated by spatio-temporal transit delay (${deltaSeconds}s, P_ST=${(stProb * 100).toFixed(1)}%) and micro-features (${(microScore * 100).toFixed(1)}%).`;
    } else {
      reasoning = `Visual appearance and kinematic profile deviate significantly (Score: ${(combined * 100).toFixed(1)}%).`;
    }
  }

  return {
    id: `match_${queryVehicle.id}_${candidateVehicle.id}_${cameraB.id}_${Date.now()}_${++_globalMatchCounter}`,
    queryVehicleId: queryVehicle.id,
    candidateVehicleId: candidateVehicle.id,
    sourceCamera: cameraA.id,
    targetCamera: cameraB.id,
    timeA,
    timeB,
    transitDeltaSeconds: deltaSeconds,
    appearanceSimilarity: appSim,
    spatioTemporalProbability: stProb,
    microFeatureMatchScore: microScore,
    directionalConsistency: 0.95,
    combinedScore: combined,
    isGroundTruthMatch,
    decision,
    reasoning,
  };
}
