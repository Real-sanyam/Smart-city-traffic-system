export type VehicleType =
  | "two_wheeler"
  | "auto_rickshaw"
  | "hatchback"
  | "bus"
  | "truck";

export interface MicroFeatures {
  helmetColor?: "black" | "white" | "red" | "yellow" | "none";
  roofRack: boolean;
  bumperScratch: boolean;
  windshieldSticker: boolean;
  cargoType?: "none" | "crates" | "tarpaulin" | "luggage";
  sunfilmTint: "clear" | "mild" | "dark";
}

export interface CameraSighting {
  cameraId: "CAM_A" | "CAM_B" | "CAM_C";
  timestamp: number; // in simulation seconds
  lane: number;
  speedKmh: number;
  extractedEmbedding: number[];
  detectedBox: { x: number; y: number; w: number; h: number };
  snapshotUrl?: string;
  illuminationLux: number;
}

export interface SimulatedVehicle {
  id: string;
  globalId: string;
  type: VehicleType;
  colorName: string;
  primaryColorHex: string;
  secondaryColorHex: string;
  microFeatures: MicroFeatures;
  trueEmbedding: number[]; // 16-d normalized appearance vector
  originCamera: "CAM_A" | "CAM_B";
  destinationCamera: "CAM_B" | "CAM_C" | "EXIT_RAMP";
  routeProgress: number; // 0 to 1
  currentPosition: [number, number, number];
  velocity: number; // units/sec
  currentLane: number;
  sightings: CameraSighting[];
  isActive: boolean;
}

export interface CameraNode {
  id: "CAM_A" | "CAM_B" | "CAM_C";
  name: string;
  junctionTitle: string;
  worldPos: [number, number, number];
  viewDirection: [number, number, number];
  fov: number;
  roadDistanceToNextKm: number; // e.g. 0.8 km
  typicalTransitSeconds: { min: number; max: number; mean: number; stdDev: number };
}

export interface ReIdMatchResult {
  id: string;
  queryVehicleId: string;
  candidateVehicleId: string;
  sourceCamera: string;
  targetCamera: string;
  timeA: number;
  timeB: number;
  transitDeltaSeconds: number;
  appearanceSimilarity: number; // 0.0 - 1.0 (Cosine similarity of visual embeddings)
  spatioTemporalProbability: number; // 0.0 - 1.0 (P(deltaT | distance, congestion))
  microFeatureMatchScore: number; // 0.0 - 1.0 (Dents, stickers, roof rack, helmet)
  directionalConsistency: number; // 0.0 - 1.0
  combinedScore: number; // Weighted Bayesian posterior
  isGroundTruthMatch: boolean;
  decision: "TRUE_MATCH" | "AMBIGUOUS" | "FALSE_ALARM";
  reasoning: string;
}

export interface OriginDestinationMatrix {
  nodes: string[];
  trips: Record<string, Record<string, number>>;
  modalSplit: Record<VehicleType, number>;
  totalReIdentified: number;
  totalTripsLogged: number;
  avgCorridorSpeedKmh: number;
}
