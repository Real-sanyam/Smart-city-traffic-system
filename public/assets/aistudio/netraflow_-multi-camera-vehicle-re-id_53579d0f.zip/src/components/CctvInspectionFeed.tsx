import React, { useState, useEffect, useRef } from "react";
import {
  Camera,
  CheckCircle2,
  AlertCircle,
  ChevronDown,
  ChevronUp,
  Activity,
  Sparkles,
  Volume2,
  VolumeX,
  X,
  ArrowRight,
  ShieldCheck,
  AlertTriangle,
  Flame,
  Gauge,
  Zap,
} from "lucide-react";
import { ReIdMatchResult, SimulatedVehicle } from "../types/reid";

interface CctvInspectionFeedProps {
  activeCameraId: "CAM_A" | "CAM_B" | "CAM_C" | "overview" | "chase";
  selectedVehicle: SimulatedVehicle | null;
  recentMatches: ReIdMatchResult[];
  onSelectVehicle: (id: string) => void;
  avgCorridorSpeedKmh?: number;
  congestionAlertThreshold?: number;
  congestionSpeedFactor?: number;
  onMitigateCongestion?: () => void;
  onChangeSpeedFactor?: (val: number) => void;
}

// Procedural soft tech chime using Web Audio API (Zero external mp3 dependencies)
function playProceduralReIdChime() {
  try {
    const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = "sine";
    osc.frequency.setValueAtTime(880, ctx.currentTime); // A5
    osc.frequency.exponentialRampToValueAtTime(1760, ctx.currentTime + 0.15); // A6

    gain.gain.setValueAtTime(0.04, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.25);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start();
    osc.stop(ctx.currentTime + 0.25);
  } catch {
    // Audio context may be restricted by autoplay policy before first gesture
  }
}

// Procedural urgent low-frequency warning tone for high-congestion alert threshold breach
function playProceduralCongestionTone() {
  try {
    const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = "sawtooth";
    osc.frequency.setValueAtTime(320, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(180, ctx.currentTime + 0.28);

    gain.gain.setValueAtTime(0.05, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.35);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start();
    osc.stop(ctx.currentTime + 0.35);
  } catch {
    // Autoplay restrictions
  }
}

export const CctvInspectionFeed: React.FC<CctvInspectionFeedProps> = ({
  activeCameraId,
  selectedVehicle,
  recentMatches,
  onSelectVehicle,
  avgCorridorSpeedKmh = 28.4,
  congestionAlertThreshold = 10.0,
  congestionSpeedFactor = 1.0,
  onMitigateCongestion,
  onChangeSpeedFactor,
}) => {
  const [isMinimized, setIsMinimized] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(false);

  // Active real-time notification state
  const [activeNotification, setActiveNotification] = useState<ReIdMatchResult | null>(null);
  const [notificationVisible, setNotificationVisible] = useState(false);
  const lastProcessedMatchId = useRef<string | null>(null);
  const notificationTimerRef = useRef<NodeJS.Timeout | null>(null);

  // High Congestion Alert State (< 10 km/h)
  const isCongested = avgCorridorSpeedKmh < congestionAlertThreshold;
  const [dismissedCongestionAlert, setDismissedCongestionAlert] = useState(false);
  const prevCongestedRef = useRef(false);

  // Sound and banner trigger when speed drops below 10 km/h threshold
  useEffect(() => {
    if (isCongested && !prevCongestedRef.current) {
      setDismissedCongestionAlert(false);
      if (soundEnabled) {
        playProceduralCongestionTone();
      }
    } else if (!isCongested && prevCongestedRef.current) {
      setDismissedCongestionAlert(false);
    }
    prevCongestedRef.current = isCongested;
  }, [isCongested, soundEnabled]);

  const cameraTitles: Record<string, string> = {
    CAM_A: "CAM 01: Silk Board North Entry",
    CAM_B: "CAM 02: Koramangala 100ft Flyover",
    CAM_C: "CAM 03: HSR Layout Sector 1 Gate",
    overview: "3D Spatial Corridor Overview",
    chase: "Vehicle Dynamic Chase Cam",
  };

  // Listen for high-confidence cross-camera re-ID matches
  useEffect(() => {
    if (recentMatches.length === 0) return;
    const latest = recentMatches[0];

    // Trigger on new high-confidence true match
    if (
      latest &&
      latest.id !== lastProcessedMatchId.current &&
      latest.decision === "TRUE_MATCH" &&
      latest.combinedScore >= 0.78
    ) {
      lastProcessedMatchId.current = latest.id;
      setActiveNotification(latest);
      setNotificationVisible(true);

      if (soundEnabled) {
        playProceduralReIdChime();
      }

      // Auto dismiss after 5 seconds
      if (notificationTimerRef.current) {
        clearTimeout(notificationTimerRef.current);
      }
      notificationTimerRef.current = setTimeout(() => {
        setNotificationVisible(false);
      }, 5200);
    }
  }, [recentMatches, soundEnabled]);

  const dismissNotification = () => {
    setNotificationVisible(false);
    if (notificationTimerRef.current) {
      clearTimeout(notificationTimerRef.current);
    }
  };

  return (
    <div
      style={{
        position: "fixed",
        top: "70px",
        right: "16px",
        width: "330px",
        maxWidth: "calc(100vw - 32px)",
        zIndex: 35,
      }}
      className="flex flex-col gap-2.5 select-none"
    >
      {/* High-Congestion Visual Alert Banner (Triggered when avg corridor speed < 10 km/h) */}
      {isCongested && !dismissedCongestionAlert && (
        <div
          style={{
            boxShadow:
              "0 0 28px rgba(239, 68, 68, 0.65), 0 0 10px rgba(245, 158, 11, 0.4)",
          }}
          className="bg-slate-950/95 border-2 border-rose-500 rounded-2xl p-3.5 text-slate-100 shadow-2xl relative overflow-hidden transition-all duration-300 animate-in fade-in slide-in-from-top-2"
        >
          {/* Animated Radiant Pulse Glow */}
          <div
            className="absolute inset-0 pointer-events-none opacity-25 animate-pulse"
            style={{
              background:
                "radial-gradient(circle at 50% 25%, #ef4444 0%, #f59e0b 50%, transparent 75%)",
            }}
          />

          {/* Alert Header */}
          <div className="flex items-center justify-between mb-2 relative z-10">
            <div className="flex items-center gap-2">
              <span className="p-1.5 rounded-lg bg-rose-500/20 text-rose-400 border border-rose-500/50 animate-bounce">
                <Flame className="w-4 h-4" />
              </span>
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="text-[9px] font-black uppercase tracking-wider text-rose-300 bg-rose-950/90 px-1.5 py-0.5 rounded border border-rose-800">
                    BOTTLENECK WARNING
                  </span>
                  <span className="text-[10px] text-amber-400 font-mono font-bold animate-pulse">
                    ● ACTIVE
                  </span>
                </div>
                <span className="text-xs font-bold text-white block leading-tight mt-0.5">
                  Critical Corridor Congestion
                </span>
              </div>
            </div>

            <button
              onClick={() => setDismissedCongestionAlert(true)}
              className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
              title="Dismiss warning card"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Speed & Threshold Telemetry Card */}
          <div className="bg-slate-900/90 border border-rose-900/50 p-2.5 rounded-xl relative z-10 mb-2.5 space-y-2">
            <div className="flex items-baseline justify-between">
              <div>
                <span className="text-[10px] text-slate-400 uppercase font-mono block">
                  Corridor Avg Speed
                </span>
                <div className="flex items-baseline gap-1.5">
                  <span className="text-2xl font-mono font-black text-rose-400 animate-pulse">
                    {avgCorridorSpeedKmh.toFixed(1)}
                  </span>
                  <span className="text-xs font-mono text-rose-300 font-semibold">km/h</span>
                  <span className="text-[9px] font-mono text-rose-300 bg-rose-950/80 px-1 py-0.5 rounded border border-rose-800">
                    &lt; {congestionAlertThreshold.toFixed(0)} km/h
                  </span>
                </div>
              </div>

              <div className="text-right">
                <span className="text-[10px] text-slate-400 uppercase font-mono block">
                  Alert Threshold
                </span>
                <div className="text-xs font-mono font-bold text-amber-400">
                  {congestionAlertThreshold.toFixed(1)} km/h
                </div>
                <span className="text-[9px] text-rose-400 font-medium">Gridlock Risk</span>
              </div>
            </div>

            {/* Gauge progress bar showing speed deficit */}
            <div className="space-y-1">
              <div className="w-full bg-slate-950 rounded-full h-2 overflow-hidden p-0.5 border border-slate-800 relative">
                {/* 10 km/h threshold line (scale 0-50 km/h => 20%) */}
                <div
                  className="absolute top-0 bottom-0 w-0.5 bg-amber-400 z-10 shadow-[0_0_4px_#f59e0b]"
                  style={{ left: "20%" }}
                  title="Alert Threshold (10 km/h)"
                />
                <div
                  className="h-full rounded-full transition-all duration-300 bg-gradient-to-r from-rose-600 via-rose-500 to-amber-500"
                  style={{
                    width: `${Math.min(100, Math.max(6, (avgCorridorSpeedKmh / 50) * 100))}%`,
                  }}
                />
              </div>
              <div className="flex justify-between text-[9px] font-mono text-slate-400">
                <span className="text-rose-400 font-bold">Stalled (0)</span>
                <span className="text-amber-400 font-semibold">Threshold (10 km/h)</span>
                <span>Normal (50)</span>
              </div>
            </div>

            <div className="text-[10px] text-slate-300 flex items-center justify-between pt-1 border-t border-slate-800/80">
              <span className="text-slate-400">Silk Board ↔ Flyover Link</span>
              <span className="text-rose-400 font-mono font-semibold flex items-center gap-1">
                <AlertTriangle className="w-3 h-3 text-amber-400" />
                Flow Degraded
              </span>
            </div>
          </div>

          {/* Action Row */}
          <div className="flex items-center gap-2 relative z-10">
            <button
              onClick={() => {
                if (onMitigateCongestion) {
                  onMitigateCongestion();
                } else if (onChangeSpeedFactor) {
                  onChangeSpeedFactor(1.2);
                }
              }}
              className="flex-1 py-1.5 px-2 bg-gradient-to-r from-rose-600 hover:from-rose-500 to-amber-600 hover:to-amber-500 text-white text-xs font-bold rounded-lg shadow-lg transition-all flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Zap className="w-3.5 h-3.5 text-amber-200" />
              <span>Mitigate / Boost Pace (1.2x)</span>
            </button>

            {onChangeSpeedFactor && (
              <button
                onClick={() => onChangeSpeedFactor(0.15)}
                className="py-1.5 px-2 bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-700 text-xs font-mono rounded-lg transition-colors cursor-pointer"
                title="Simulate severe crawl (< 10 km/h)"
              >
                Crawl
              </button>
            )}
          </div>
        </div>
      )}

      {/* Collapsed Congestion Alert Pill (if user dismissed banner but speed remains < 10 km/h) */}
      {isCongested && dismissedCongestionAlert && (
        <button
          onClick={() => setDismissedCongestionAlert(false)}
          className="w-full bg-rose-950/90 border border-rose-500/80 hover:bg-rose-900/90 text-rose-200 text-xs font-medium py-1.5 px-3 rounded-xl flex items-center justify-between cursor-pointer transition-all animate-pulse shadow-lg"
        >
          <span className="flex items-center gap-1.5 font-bold">
            <Flame className="w-3.5 h-3.5 text-rose-400" />
            <span>CONGESTION ALERT (&lt;10 km/h)</span>
          </span>
          <span className="font-mono text-rose-300 font-bold flex items-center gap-1">
            {avgCorridorSpeedKmh.toFixed(1)} km/h • Open
          </span>
        </button>
      )}

      {/* Real-Time High-Confidence Match Notification Alert with Visual Pulse */}
      {notificationVisible && activeNotification && (
        <div
          style={{
            boxShadow: "0 0 24px rgba(16, 185, 129, 0.45)",
          }}
          className="bg-slate-950/95 border-2 border-emerald-400/90 rounded-2xl p-3.5 text-slate-100 shadow-2xl relative overflow-hidden transition-all duration-300 animate-in fade-in slide-in-from-top-2"
        >
          {/* Subtle animated radiant pulse aura background */}
          <div
            className="absolute inset-0 pointer-events-none opacity-20"
            style={{
              background: "radial-gradient(circle at 50% 50%, #10b981 0%, transparent 70%)",
            }}
          />

          {/* Alert Header */}
          <div className="flex items-center justify-between mb-2 relative z-10">
            <div className="flex items-center gap-1.5">
              <span className="p-1 rounded-lg bg-emerald-500/20 text-emerald-400 border border-emerald-500/40">
                <Sparkles className="w-3.5 h-3.5" />
              </span>
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-400 block leading-tight">
                  Cross-Camera Re-ID Match
                </span>
                <span className="text-xs font-bold text-white flex items-center gap-1">
                  Confidence: {(activeNotification.combinedScore * 100).toFixed(1)}%
                </span>
              </div>
            </div>

            <button
              onClick={dismissNotification}
              className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Match Trajectory Details */}
          <div className="space-y-1.5 text-xs bg-slate-900/90 border border-emerald-900/40 p-2.5 rounded-xl relative z-10 mb-2.5">
            <div className="flex items-center justify-between text-[11px] font-mono">
              <span className="text-slate-400">Route Link:</span>
              <span className="text-cyan-300 font-bold flex items-center gap-1">
                {activeNotification.sourceCamera} <ArrowRight className="w-3 h-3 text-emerald-400" /> {activeNotification.targetCamera}
              </span>
            </div>
            <div className="flex items-center justify-between text-[11px]">
              <span className="text-slate-400">Transit Travel Time:</span>
              <span className="font-mono text-emerald-400 font-semibold">
                {activeNotification.transitDeltaSeconds}s (Window Aligned)
              </span>
            </div>
            <div className="flex items-center justify-between text-[11px]">
              <span className="text-slate-400">Appearance Cosine Sim:</span>
              <span className="font-mono text-cyan-400 font-semibold">
                {(activeNotification.appearanceSimilarity * 100).toFixed(1)}%
              </span>
            </div>
          </div>

          {/* Action Row */}
          <div className="flex items-center justify-between relative z-10">
            <span className="text-[10px] text-slate-400 flex items-center gap-1">
              <ShieldCheck className="w-3 h-3 text-emerald-400" />
              Non-Plate Visual Re-ID
            </span>
            <button
              onClick={() => {
                onSelectVehicle(activeNotification.candidateVehicleId);
                dismissNotification();
              }}
              className="px-2.5 py-1 bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold rounded-lg shadow transition-colors cursor-pointer"
            >
              Inspect Vehicle
            </button>
          </div>
        </div>
      )}

      {/* Active Camera Feed Simulator Card */}
      <div
        className={`bg-slate-950/90 border rounded-2xl shadow-xl overflow-hidden text-slate-200 transition-colors duration-300 ${
          isCongested
            ? "border-rose-500/80 shadow-[0_0_20px_rgba(239,68,68,0.25)]"
            : "border-slate-800"
        }`}
      >
        {/* Header */}
        <div className="px-3.5 py-2.5 bg-slate-900/90 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            {isCongested ? (
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-rose-500"></span>
              </span>
            ) : (
              <span className="w-2 h-2 rounded-full bg-emerald-400" />
            )}
            <span className="text-xs font-bold text-white truncate max-w-[170px]">
              {cameraTitles[activeCameraId] || "CCTV Feed"}
            </span>
            {isCongested && (
              <span className="px-1.5 py-0.2 rounded text-[9px] font-mono font-bold bg-rose-950 text-rose-300 border border-rose-800 animate-pulse">
                &lt;10km/h
              </span>
            )}
          </div>

          <div className="flex items-center gap-1">
            <button
              onClick={() => setSoundEnabled(!soundEnabled)}
              className={`p-1 rounded transition-colors ${
                soundEnabled ? "text-cyan-400 bg-slate-800" : "text-slate-500 hover:text-slate-300"
              }`}
              title={soundEnabled ? "Mute Re-ID & alert audio chimes" : "Enable audio alerts"}
            >
              {soundEnabled ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
            </button>

            <button
              onClick={() => setIsMinimized(!isMinimized)}
              className="p-1 text-slate-400 hover:text-white rounded hover:bg-slate-800 transition-colors cursor-pointer"
            >
              {isMinimized ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronUp className="w-3.5 h-3.5" />}
            </button>
          </div>
        </div>

        {!isMinimized && (
          <div className="p-3 space-y-3">
            {/* Simulated Camera Viewfinder */}
            <div
              className={`relative aspect-video bg-slate-900 rounded-xl overflow-hidden border flex items-center justify-center transition-colors duration-300 ${
                isCongested ? "border-rose-500/70" : "border-slate-800"
              }`}
            >
              {/* Scanline Grid Effect */}
              <div
                className="absolute inset-0 opacity-15 pointer-events-none"
                style={{
                  backgroundImage:
                    "linear-gradient(#38bdf8 1px, transparent 1px), linear-gradient(90deg, #38bdf8 1px, transparent 1px)",
                  backgroundSize: "20px 20px",
                }}
              />

              {/* Camera Status HUD */}
              <div className="absolute top-2 left-2 text-[10px] font-mono text-cyan-400 bg-slate-950/80 px-2 py-0.5 rounded border border-cyan-800/60 flex items-center gap-1">
                <Camera className="w-3 h-3" />
                <span>REC • 30 FPS • 1080p</span>
              </div>

              {/* Congestion Alert Overlay in Viewfinder */}
              {isCongested && (
                <div className="absolute top-2 right-2 text-[10px] font-mono font-bold text-rose-300 bg-rose-950/90 px-2 py-0.5 rounded border border-rose-500/80 flex items-center gap-1 animate-pulse shadow-lg">
                  <AlertTriangle className="w-3 h-3 text-rose-400" />
                  <span>FLOW &lt; 10 km/h ({avgCorridorSpeedKmh.toFixed(1)})</span>
                </div>
              )}

              <div className="absolute bottom-2 left-2 text-[10px] font-mono text-slate-400 bg-slate-950/80 px-2 py-0.5 rounded border border-slate-800">
                LPR: DISABLED (NON-PLATE RE-ID)
              </div>

              {/* Selected or Tracked Vehicle Crop Overlay */}
              {selectedVehicle ? (
                <div className="p-3 text-center space-y-1">
                  <div className="inline-block px-2.5 py-1 rounded bg-cyan-950 text-cyan-300 border border-cyan-700 text-xs font-mono font-bold">
                    [TRACK-{selectedVehicle.globalId}]
                  </div>
                  <div className="text-xs font-bold text-white capitalize">
                    {selectedVehicle.colorName} {selectedVehicle.type.replace("_", " ")}
                  </div>
                  <div className="text-[10px] text-slate-400">
                    Lane: {selectedVehicle.currentLane === -1 ? "Fast" : selectedVehicle.currentLane === 0 ? "Middle" : "Service"} • Spd: {(selectedVehicle.velocity * 3.6).toFixed(0)} km/h
                  </div>
                </div>
              ) : (
                <div className="text-center p-3 text-slate-500 text-xs flex flex-col items-center gap-1">
                  <Activity className="w-5 h-5 text-slate-600" />
                  <span>Click any vehicle in 3D scene to inspect visual embedding</span>
                </div>
              )}
            </div>

            {/* Selected Vehicle Visual Signature Breakdown */}
            {selectedVehicle && (
              <div className="space-y-1.5 text-xs bg-slate-900/80 p-2.5 rounded-xl border border-slate-800">
                <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                  Extracted Micro-Attributes
                </div>
                <div className="grid grid-cols-2 gap-1.5 text-[11px]">
                  <div className="flex justify-between bg-slate-950/60 p-1.5 rounded">
                    <span className="text-slate-400">Roof Rack:</span>
                    <span className={selectedVehicle.microFeatures.roofRack ? "text-emerald-400 font-bold" : "text-slate-500"}>
                      {selectedVehicle.microFeatures.roofRack ? "Present" : "None"}
                    </span>
                  </div>
                  <div className="flex justify-between bg-slate-950/60 p-1.5 rounded">
                    <span className="text-slate-400">Scratch:</span>
                    <span className={selectedVehicle.microFeatures.bumperScratch ? "text-amber-400 font-bold" : "text-slate-500"}>
                      {selectedVehicle.microFeatures.bumperScratch ? "Detected" : "None"}
                    </span>
                  </div>
                  <div className="flex justify-between bg-slate-950/60 p-1.5 rounded">
                    <span className="text-slate-400">Sticker:</span>
                    <span className={selectedVehicle.microFeatures.windshieldSticker ? "text-cyan-400 font-bold" : "text-slate-500"}>
                      {selectedVehicle.microFeatures.windshieldSticker ? "FASTag" : "None"}
                    </span>
                  </div>
                  <div className="flex justify-between bg-slate-950/60 p-1.5 rounded">
                    <span className="text-slate-400">Helmet:</span>
                    <span className="text-slate-300 font-bold capitalize">
                      {selectedVehicle.microFeatures.helmetColor || "N/A"}
                    </span>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Live Re-ID Match Stream Ticker */}
      <div className="bg-slate-950/90 border border-slate-800 rounded-2xl shadow-xl overflow-hidden text-slate-200">
        <div className="px-3.5 py-2 bg-slate-900/90 border-b border-slate-800 flex items-center justify-between text-xs font-bold text-slate-300">
          <span className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
            Live Re-ID Stream
          </span>
          <span className="text-[10px] text-slate-400 font-mono">
            {recentMatches.length} Matches Logged
          </span>
        </div>

        <div className="max-h-48 overflow-y-auto divide-y divide-slate-800/60 p-1">
          {recentMatches.length === 0 ? (
            <div className="py-4 text-center text-xs text-slate-500">
              Vehicles traversing corridor... matches appear when passing downstream cameras.
            </div>
          ) : (
            recentMatches.slice(0, 5).map((m, idx) => {
              const isTrue = m.decision === "TRUE_MATCH";
              const isTopPulse = idx === 0 && isTrue;

              return (
                <div
                  key={`${m.id}_${idx}`}
                  style={
                    isTopPulse
                      ? {
                          boxShadow: "0 0 14px rgba(16, 185, 129, 0.35)",
                        }
                      : {}
                  }
                  className={`p-2 text-xs transition-all duration-300 rounded-lg ${
                    isTopPulse
                      ? "bg-emerald-950/50 border border-emerald-500/70"
                      : "hover:bg-slate-900/60"
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-mono text-cyan-300 font-bold text-[11px] flex items-center gap-1">
                      {m.sourceCamera} → {m.targetCamera}
                      {isTopPulse && (
                        <span className="px-1.5 py-0.2 rounded-full bg-emerald-500/20 text-emerald-300 text-[9px] font-bold border border-emerald-500/50">
                          NEW
                        </span>
                      )}
                    </span>
                    {isTrue ? (
                      <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center gap-0.5">
                        <CheckCircle2 className="w-2.5 h-2.5" /> CONFIRMED
                      </span>
                    ) : (
                      <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-amber-500/20 text-amber-400 border border-amber-500/40 flex items-center gap-0.5">
                        <AlertCircle className="w-2.5 h-2.5" /> REJECTED
                      </span>
                    )}
                  </div>
                  <div className="flex items-center justify-between text-[10px] text-slate-400">
                    <span>Δt: {m.transitDeltaSeconds}s</span>
                    <span>App: {(m.appearanceSimilarity * 100).toFixed(0)}%</span>
                    <span className={isTrue ? "text-emerald-400 font-bold" : ""}>
                      Conf: {(m.combinedScore * 100).toFixed(0)}%
                    </span>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
