import React, { useState } from "react";
import {
  Video,
  Eye,
  Sliders,
  Sparkles,
  BookOpen,
  BarChart3,
  HelpCircle,
  Play,
  RotateCcw,
  Layers,
  ChevronDown,
  ChevronUp,
  Flame,
  Activity,
  Grid,
} from "lucide-react";

interface ControlDockProps {
  activeCameraView: "overview" | "CAM_A" | "CAM_B" | "CAM_C" | "chase";
  onSelectCameraView: (view: "overview" | "CAM_A" | "CAM_B" | "CAM_C" | "chase") => void;
  showFrustums: boolean;
  onToggleFrustums: () => void;
  showTrajectories?: boolean;
  onToggleTrajectories?: () => void;
  showCalibration?: boolean;
  onToggleCalibration?: () => void;
  congestionSpeedFactor: number;
  onChangeSpeedFactor: (val: number) => void;
  onOpenLab: () => void;
  onOpenArchitecture: () => void;
  onOpenDashboard: () => void;
  onOpenAiReasoner: () => void;
  onOpenHeatmap: () => void;
  onResetSimulation: () => void;
  isAiLoading: boolean;
}

export const ControlDock: React.FC<ControlDockProps> = ({
  activeCameraView,
  onSelectCameraView,
  showFrustums,
  onToggleFrustums,
  showTrajectories = true,
  onToggleTrajectories,
  showCalibration = false,
  onToggleCalibration,
  congestionSpeedFactor,
  onChangeSpeedFactor,
  onOpenLab,
  onOpenArchitecture,
  onOpenDashboard,
  onOpenAiReasoner,
  onOpenHeatmap,
  onResetSimulation,
  isAiLoading,
}) => {
  const [isCollapsed, setIsCollapsed] = useState(false);

  return (
    <div
      style={{
        position: "fixed",
        bottom: isCollapsed ? "-105px" : "18px",
        left: "50%",
        transform: "translateX(-50%)",
        maxWidth: "min(960px, 95vw)",
        zIndex: 40,
        transition: "bottom 0.3s cubic-bezier(0.16, 1, 0.3, 1)",
      }}
      className="w-full flex flex-col items-center select-none"
    >
      {/* Collapse / Expand Toggle Button */}
      <button
        onClick={() => setIsCollapsed(!isCollapsed)}
        className="mb-1.5 px-3 py-1 bg-slate-900/90 text-cyan-400 hover:text-cyan-300 border border-slate-700/80 rounded-full text-xs font-medium flex items-center gap-1.5 shadow-lg cursor-pointer transition-colors"
      >
        {isCollapsed ? (
          <>
            <ChevronUp className="w-3.5 h-3.5" />
            <span>Show Re-ID Control Deck</span>
          </>
        ) : (
          <>
            <ChevronDown className="w-3.5 h-3.5" />
            <span>Hide Control Deck (Zen Mode)</span>
          </>
        )}
      </button>

      {/* Main Glassmorphic Control Dock (Solid/rgba surfaces - no backdrop-filter over WebGL) */}
      <div className="w-full bg-slate-950/95 border border-slate-800 rounded-2xl shadow-2xl p-3 px-4 flex flex-wrap items-center justify-between gap-3 text-slate-200">
        {/* Left: Camera Feed Switcher */}
        <div className="flex items-center gap-1.5 bg-slate-900/90 p-1 rounded-xl border border-slate-800">
          <span className="text-[11px] font-semibold text-slate-400 px-2 flex items-center gap-1">
            <Video className="w-3 h-3 text-cyan-400" />
            Feeds:
          </span>
          <button
            onClick={() => onSelectCameraView("overview")}
            className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-all ${
              activeCameraView === "overview"
                ? "bg-cyan-500 text-slate-950 font-bold"
                : "text-slate-300 hover:bg-slate-800"
            }`}
          >
            3D God View
          </button>
          <button
            onClick={() => onSelectCameraView("CAM_A")}
            className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-all ${
              activeCameraView === "CAM_A"
                ? "bg-cyan-500 text-slate-950 font-bold"
                : "text-slate-300 hover:bg-slate-800"
            }`}
          >
            Cam 01 Entry
          </button>
          <button
            onClick={() => onSelectCameraView("CAM_B")}
            className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-all ${
              activeCameraView === "CAM_B"
                ? "bg-cyan-500 text-slate-950 font-bold"
                : "text-slate-300 hover:bg-slate-800"
            }`}
          >
            Cam 02 Flyover
          </button>
          <button
            onClick={() => onSelectCameraView("CAM_C")}
            className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-all ${
              activeCameraView === "CAM_C"
                ? "bg-cyan-500 text-slate-950 font-bold"
                : "text-slate-300 hover:bg-slate-800"
            }`}
          >
            Cam 03 Exit
          </button>
          <button
            onClick={() => onSelectCameraView("chase")}
            className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-all ${
              activeCameraView === "chase"
                ? "bg-amber-400 text-slate-950 font-bold"
                : "text-slate-300 hover:bg-slate-800"
            }`}
          >
            Chase Cam
          </button>
        </div>

        {/* Center: Traffic Flow Speed & Frustums */}
        <div className="flex items-center gap-3 bg-slate-900/90 px-3 py-1.5 rounded-xl border border-slate-800">
          <button
            onClick={onToggleFrustums}
            className={`px-2 py-1 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-all ${
              showFrustums
                ? "bg-cyan-950/80 text-cyan-300 border border-cyan-800/80"
                : "bg-slate-800 text-slate-400"
            }`}
            title="Toggle CCTV Field-of-View Visual Frustums"
          >
            <Layers className="w-3.5 h-3.5" />
            <span>FOV Frustums</span>
          </button>

          <button
            onClick={onToggleTrajectories}
            className={`px-2 py-1 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-all cursor-pointer ${
              showTrajectories
                ? "bg-cyan-950/80 text-cyan-300 border border-cyan-800/80"
                : "bg-slate-800 text-slate-400"
            }`}
            title="Toggle Vehicle Trajectory Lines & Spatio-Temporal Flow Conduits"
          >
            <Activity className="w-3.5 h-3.5" />
            <span>Trajectory Lines</span>
          </button>

          <button
            onClick={onToggleCalibration}
            className={`px-2 py-1 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-all cursor-pointer ${
              showCalibration
                ? "bg-amber-950/80 text-amber-300 border border-amber-800/80 shadow-sm"
                : "bg-slate-800 text-slate-400 hover:text-slate-200"
            }`}
            title="Toggle Homography Ground Calibration Grids & Metric Rays (IPM)"
          >
            <Grid className="w-3.5 h-3.5" />
            <span>Homography Grid</span>
          </button>

          <div className="flex items-center gap-2">
            <span className="text-[11px] text-slate-400 flex items-center gap-1">
              <Sliders className="w-3 h-3 text-cyan-400" />
              Traffic Pace:
            </span>
            <input
              type="range"
              min="0.1"
              max="2.2"
              step="0.05"
              value={congestionSpeedFactor}
              onChange={(e) => onChangeSpeedFactor(parseFloat(e.target.value))}
              className="w-20 accent-cyan-400 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
              title="Adjust traffic speed factor (drag below ~0.25x to trigger <10 km/h alert)"
            />
            <span
              className={`text-xs font-mono font-bold w-9 ${
                congestionSpeedFactor <= 0.25 ? "text-rose-400 animate-pulse" : "text-cyan-400"
              }`}
            >
              {congestionSpeedFactor.toFixed(2)}x
            </span>
          </div>

          <button
            onClick={onResetSimulation}
            className="p-1 text-slate-400 hover:text-white rounded hover:bg-slate-800 transition-colors"
            title="Reset Vehicle Fleet"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Right: Specialized Re-ID Action Modals */}
        <div className="flex items-center gap-2">
          {/* Identical Vehicle Challenge Lab */}
          <button
            onClick={onOpenLab}
            className="px-3 py-1.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 text-xs font-bold rounded-xl flex items-center gap-1.5 shadow-md transition-transform active:scale-95 cursor-pointer"
          >
            <HelpCircle className="w-3.5 h-3.5" />
            <span>Disambiguate Identical Cars</span>
          </button>

          {/* AI Spatio-Temporal Reasoner */}
          <button
            onClick={onOpenAiReasoner}
            disabled={isAiLoading}
            className="px-3 py-1.5 bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 shadow-md transition-transform active:scale-95 cursor-pointer disabled:opacity-50"
          >
            <Sparkles className="w-3.5 h-3.5 text-yellow-300" />
            <span>Gemini 4 Reasoning</span>
          </button>

          {/* D3 Traffic Heatmap */}
          <button
            onClick={onOpenHeatmap}
            className="px-3 py-1.5 bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 text-slate-950 text-xs font-bold rounded-xl flex items-center gap-1.5 shadow-md transition-transform active:scale-95 cursor-pointer"
          >
            <Flame className="w-3.5 h-3.5" />
            <span>Density Heatmap</span>
          </button>

          {/* OD Flow Matrix */}
          <button
            onClick={onOpenDashboard}
            className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-cyan-300 text-xs font-medium rounded-xl flex items-center gap-1.5 border border-slate-700 transition-colors cursor-pointer"
          >
            <BarChart3 className="w-3.5 h-3.5" />
            <span>OD Flows</span>
          </button>

          {/* Technical Architecture & Methodology Guide */}
          <button
            onClick={onOpenArchitecture}
            className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium rounded-xl flex items-center gap-1.5 border border-slate-700 transition-colors cursor-pointer"
          >
            <BookOpen className="w-3.5 h-3.5 text-cyan-400" />
            <span>Methodology</span>
          </button>
        </div>
      </div>
    </div>
  );
};
