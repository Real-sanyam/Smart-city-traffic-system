import React, { useState } from "react";
import { User, LogIn, LogOut, Save, FolderOpen, Shield, Check } from "lucide-react";
import { auth, googleProvider, signInWithPopup, signOut } from "../lib/firebase";
import { User as FirebaseUser } from "firebase/auth";

interface AuthAndSaveBarProps {
  user: FirebaseUser | null;
  onSaveStudy: () => void;
  onLoadSavedStudies: () => void;
  isSaving: boolean;
  saveSuccess: boolean;
}

export const AuthAndSaveBar: React.FC<AuthAndSaveBarProps> = ({
  user,
  onSaveStudy,
  onLoadSavedStudies,
  isSaving,
  saveSuccess,
}) => {
  const [authError, setAuthError] = useState<string | null>(null);

  const handleSignIn = async () => {
    setAuthError(null);
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (err: any) {
      console.error("Sign-in error:", err);
      setAuthError(err.message || "Failed to sign in");
    }
  };

  const handleSignOut = async () => {
    try {
      await signOut(auth);
    } catch (err: any) {
      console.error("Sign-out error:", err);
    }
  };

  return (
    <div
      style={{
        position: "fixed",
        top: "14px",
        left: "50%",
        transform: "translateX(-50%)",
        maxWidth: "min(1100px, 96vw)",
        zIndex: 40,
      }}
      className="w-full flex items-center justify-between bg-slate-950/95 border border-slate-800 rounded-2xl shadow-xl px-4 py-2.5 text-slate-200 select-none"
    >
      {/* Brand & Mission Badge */}
      <div className="flex items-center gap-3">
        <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center text-slate-950 font-black text-sm shadow-md shadow-cyan-950/50">
          NF
        </div>
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-sm font-bold text-white tracking-tight">NetraFlow</h1>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-950/80 text-cyan-300 border border-cyan-800">
              Multi-Camera Re-ID
            </span>
          </div>
          <p className="text-[11px] text-slate-400 hidden sm:block">
            Spatio-Temporal & Visual Re-ID in Non-Plate Dense Traffic
          </p>
        </div>
      </div>

      {/* Persistence & Authentication Actions */}
      <div className="flex items-center gap-2.5">
        {/* Save Study */}
        <button
          onClick={onSaveStudy}
          disabled={isSaving}
          className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
            saveSuccess
              ? "bg-emerald-600 text-white"
              : "bg-slate-900 hover:bg-slate-800 text-cyan-300 border border-slate-700"
          }`}
          title="Save Current Corridor & OD Flow Study to Firestore"
        >
          {saveSuccess ? (
            <>
              <Check className="w-3.5 h-3.5" />
              <span>Saved!</span>
            </>
          ) : (
            <>
              <Save className="w-3.5 h-3.5" />
              <span>{isSaving ? "Saving..." : "Save Study"}</span>
            </>
          )}
        </button>

        {/* Load Saved Studies */}
        <button
          onClick={onLoadSavedStudies}
          className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-700 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
          title="Load Previous Studies from Firestore"
        >
          <FolderOpen className="w-3.5 h-3.5" />
          <span>Studies</span>
        </button>

        {/* Google Authentication */}
        {user ? (
          <div className="flex items-center gap-2 pl-2 border-l border-slate-800">
            {user.photoURL ? (
              <img
                src={user.photoURL}
                alt={user.displayName || "User"}
                className="w-7 h-7 rounded-full border border-cyan-500/50"
              />
            ) : (
              <div className="w-7 h-7 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-xs text-white">
                <User className="w-4 h-4" />
              </div>
            )}
            <span className="text-xs font-semibold text-slate-200 hidden md:block max-w-[100px] truncate">
              {user.displayName?.split(" ")[0] || "User"}
            </span>
            <button
              onClick={handleSignOut}
              className="p-1.5 text-slate-400 hover:text-rose-400 rounded-lg hover:bg-slate-900 transition-colors cursor-pointer"
              title="Sign Out"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        ) : (
          <button
            onClick={handleSignIn}
            className="px-3 py-1.5 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-md transition-transform active:scale-95 cursor-pointer"
          >
            <LogIn className="w-3.5 h-3.5" />
            <span>Sign In</span>
          </button>
        )}
      </div>
    </div>
  );
};
