import React, { useState } from "react";
import {
  X,
  CheckCircle,
  AlertTriangle,
  XCircle,
  Sliders,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  Cpu,
  BarChart3,
  Camera,
  Layers,
} from "lucide-react";
import { CameraHistogram } from "./CameraHistogram";
import { SimulatedVehicle } from "../types/reid";

interface DisambiguationLabProps {
  isOpen: boolean;
  onClose: () => void;
  onRunAiAnalysis: (scenario: any) => void;
  isAiLoading: boolean;
  vehicles?: SimulatedVehicle[];
  activeCameraId?: string;
}

export const DisambiguationLab: React.FC<DisambiguationLabProps> = ({
  isOpen,
  onClose,
  onRunAiAnalysis,
  isAiLoading,
  vehicles = [],
  activeCameraId = "CAM_B",
}) => {
  // Navigation tab state inside the Disambiguation Lab
  const [activeTab, setActiveTab] = useState<"evaluator" | "histogram">("evaluator");
  const [selectedHistogramCamera, setSelectedHistogramCamera] = useState<"CAM_A" | "CAM_B" | "CAM_C">("CAM_B");
  const [showInlineHistogram, setShowInlineHistogram] = useState(false);

  // Bayesian weight sliders
  const [weightApp, setWeightApp] = useState(0.4);
  const [weightSt, setWeightSt] = useState(0.4);
  const [weightMicro, setWeightMicro] = useState(0.2);

  // Congestion offset (simulates rush hour vs night free flow)
  const [congestionLevel, setCongestionLevel] = useState<"normal" | "heavy" | "freeflow">("normal");

  if (!isOpen) return null;

  // Expected travel times for 500m urban corridor
  const expectedTransitMean = congestionLevel === "heavy" ? 110 : congestionLevel === "freeflow" ? 40 : 65;
  const transitStdDev = congestionLevel === "heavy" ? 25 : 12;

  // Query vehicle seen at Camera A at 08:30:00
  const queryVehicle = {
    plate: "[RESTRICTED - NO OCR]",
    make: "Maruti Suzuki Swift",
    color: "Arctic White (#F0F2F5)",
    timeA: "08:30:00",
    lane: "Lane 2 (Middle)",
    microFeatures: {
      roofRack: false,
      fastagSticker: true,
      bumperScratch: true,
      sunfilm: "Mild smoke tint (35%)",
    },
  };

  // Candidates detected at Camera B (500m downstream)
  const candidates = [
    {
      id: "Candidate 1",
      name: "White Swift A",
      timeB: "08:30:22",
      deltaT: 22,
      rawVisualSim: 0.89,
      microFeatures: {
        roofRack: false,
        fastagSticker: false,
        bumperScratch: false,
        sunfilm: "Dark limo tint (15%)",
      },
      speedImplied: ((0.5 / 22) * 3600).toFixed(1), // 81.8 km/h
    },
    {
      id: "Candidate 2 (True Target)",
      name: "White Swift B",
      timeB: "08:31:08",
      deltaT: 68,
      rawVisualSim: 0.91,
      microFeatures: {
        roofRack: false,
        fastagSticker: true,
        bumperScratch: true,
        sunfilm: "Mild smoke tint (35%)",
      },
      speedImplied: ((0.5 / 68) * 3600).toFixed(1), // 26.5 km/h
    },
    {
      id: "Candidate 3",
      name: "White Swift C",
      timeB: "08:33:45",
      deltaT: 225,
      rawVisualSim: 0.88,
      microFeatures: {
        roofRack: true, // Aftermarket luggage rack!
        fastagSticker: false,
        bumperScratch: false,
        sunfilm: "Clear glass (70%)",
      },
      speedImplied: ((0.5 / 225) * 3600).toFixed(1), // 8.0 km/h
    },
  ];

  // Evaluate candidate scores based on current weights
  const evaluated = candidates.map((c) => {
    // 1. Spatio-temporal score
    const z = (c.deltaT - expectedTransitMean) / transitStdDev;
    let stScore = Math.exp(-0.5 * z * z);
    if (c.deltaT < 25) stScore = 0.02; // physical speed limit violation
    if (c.deltaT > 180) stScore = 0.06; // stopped / deviated

    // 2. Micro-feature score
    let microScore = 0.5;
    if (c.microFeatures.fastagSticker === queryVehicle.microFeatures.fastagSticker) microScore += 0.2;
    else microScore -= 0.2;

    if (c.microFeatures.bumperScratch === queryVehicle.microFeatures.bumperScratch) microScore += 0.25;
    else microScore -= 0.15;

    if (c.microFeatures.roofRack === queryVehicle.microFeatures.roofRack) microScore += 0.15;
    else microScore -= 0.35; // High penalty for luggage rack mismatch!

    microScore = Math.max(0.05, Math.min(0.99, microScore));

    // Total normalized composite score
    const totalWeight = weightApp + weightSt + weightMicro || 1.0;
    const finalScore =
      (weightApp * c.rawVisualSim + weightSt * stScore + weightMicro * microScore) / totalWeight;

    return {
      ...c,
      stScore,
      microScore,
      finalScore,
    };
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 select-none">
      <div className="bg-slate-900 border border-slate-700 w-full max-w-5xl rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/80">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30">
              <Cpu className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                Identical Vehicle Disambiguation Lab
                <span className="text-xs px-2.5 py-0.5 rounded-full bg-cyan-950 text-cyan-400 border border-cyan-800">
                  Non-Plate Re-ID
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Solving the "White Hatchback Problem": Separating visually identical vehicles without license plate OCR.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Lab Navigation Tabs */}
        <div className="px-6 py-2.5 bg-slate-950 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab("evaluator")}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-2 transition-all cursor-pointer ${
                activeTab === "evaluator"
                  ? "bg-cyan-500/20 text-cyan-300 border border-cyan-500/50 shadow-sm"
                  : "text-slate-400 hover:text-white hover:bg-slate-800/60"
              }`}
            >
              <Sliders className="w-3.5 h-3.5 text-cyan-400" />
              <span>Bayesian Disambiguation Evaluator</span>
            </button>

            <button
              onClick={() => setActiveTab("histogram")}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-2 transition-all cursor-pointer ${
                activeTab === "histogram"
                  ? "bg-cyan-500/20 text-cyan-300 border border-cyan-500/50 shadow-sm"
                  : "text-slate-400 hover:text-white hover:bg-slate-800/60"
              }`}
            >
              <BarChart3 className="w-3.5 h-3.5 text-cyan-400" />
              <span>Camera Color Histogram</span>
              <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                Live Ambiguity Spectrum
              </span>
            </button>
          </div>

          <div className="flex items-center gap-3 text-xs text-slate-400">
            <span className="hidden sm:inline text-[11px] font-mono text-slate-400">
              Corridor Focus: <span className="text-cyan-400 font-bold">Silk Board → Koramangala (500m)</span>
            </span>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-6">
          {activeTab === "histogram" ? (
            /* Dedicated Camera Color Histogram View */
            <div className="space-y-4">
              <CameraHistogram
                selectedCameraId={selectedHistogramCamera}
                onSelectCamera={setSelectedHistogramCamera}
                vehicles={vehicles}
                queryColorHex="#f0f2f5"
                queryColorName="Arctic White"
              />
            </div>
          ) : (
            /* Bayesian Disambiguation Evaluator View */
            <>
              {/* Query Vehicle Card vs Downstream Cameras */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {/* Query Card */}
                <div className="bg-slate-950/80 border border-cyan-800/80 p-4 rounded-xl relative overflow-hidden">
                  <div className="absolute top-2 right-2 px-2 py-0.5 bg-cyan-500/20 text-cyan-300 text-[10px] font-bold rounded uppercase">
                    Query Vehicle
                  </div>
                  <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
                    Captured at Camera 01 (Entry)
                  </h3>
                  <div className="text-sm font-bold text-white mb-1">{queryVehicle.make}</div>
                  <div className="text-xs text-slate-300 flex items-center gap-2 mb-3">
                    <span className="w-3 h-3 rounded-full bg-slate-100 border border-slate-400 inline-block" />
                    <span>{queryVehicle.color}</span>
                  </div>

                  <div className="space-y-1.5 text-xs text-slate-300 bg-slate-900/90 p-2.5 rounded-lg border border-slate-800">
                    <div className="flex justify-between">
                      <span className="text-slate-400">Timestamp:</span>
                      <span className="font-mono text-cyan-300 font-bold">{queryVehicle.timeA}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">FASTag Sticker:</span>
                      <span className="text-emerald-400 font-semibold">Yes (Top-Right)</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Bumper Scratch:</span>
                      <span className="text-amber-400 font-semibold">Yes (Left Rear)</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Roof Rack:</span>
                      <span className="text-slate-400">None</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Window Tint:</span>
                      <span className="text-slate-300">{queryVehicle.microFeatures.sunfilm}</span>
                    </div>
                  </div>
                </div>

                {/* Explanation & Corridor Parameters */}
                <div className="md:col-span-2 bg-slate-950/80 border border-slate-800 p-4 rounded-xl flex flex-col justify-between">
                  <div>
                    <h3 className="text-xs font-bold text-amber-400 uppercase tracking-wider mb-1 flex items-center gap-1.5">
                      <AlertTriangle className="w-4 h-4" />
                      The Identical Vehicle Dilemma
                    </h3>
                    <p className="text-xs text-slate-300 leading-relaxed mb-3">
                      All 3 candidates below are <strong>white hatchbacks</strong> of the exact same model.
                      Raw deep visual embeddings (ResNet-50 / OSNet) produce nearly indistinguishable cosine similarities:{" "}
                      <code className="text-cyan-300 bg-slate-900 px-1 py-0.5 rounded">0.89 vs 0.91 vs 0.88</code>.
                      If you rely on appearance alone, the matching engine suffers catastrophic identity switches!
                    </p>
                  </div>

                  {/* Congestion Setting & Expected Travel Time */}
                  <div className="flex items-center justify-between bg-slate-900/90 p-3 rounded-lg border border-slate-800 text-xs">
                    <div>
                      <span className="text-slate-400 block text-[11px]">Corridor Distance:</span>
                      <span className="font-bold text-white">500 meters (Cam 01 → Cam 02)</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[11px]">Traffic Regime:</span>
                      <div className="flex gap-1.5 mt-0.5">
                        {(["freeflow", "normal", "heavy"] as const).map((lvl) => (
                          <button
                            key={lvl}
                            onClick={() => setCongestionLevel(lvl)}
                            className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase transition-colors cursor-pointer ${
                              congestionLevel === lvl
                                ? "bg-cyan-500 text-slate-950"
                                : "bg-slate-800 text-slate-400 hover:text-white"
                            }`}
                          >
                            {lvl}
                          </button>
                        ))}
                      </div>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[11px]">Expected Transit Window:</span>
                      <span className="font-bold text-cyan-400 font-mono">
                        {expectedTransitMean}s (±{transitStdDev}s)
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Inline Camera Color Histogram Banner / Quick Toggle */}
              <div className="bg-slate-950/90 border border-slate-800 p-3.5 rounded-xl flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-amber-500/10 text-amber-400 border border-amber-500/20">
                    <BarChart3 className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-white">
                        Camera 02 Visual Signature Collision Alert:
                      </span>
                      <span className="text-[10px] font-mono px-2 py-0.2 rounded bg-rose-950/60 text-rose-300 border border-rose-800">
                        54.2% White/Silver Fleet Share
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400">
                      High candidate density in the Arctic White spectrum makes visual-only Re-ID unreliable.
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setShowInlineHistogram(!showInlineHistogram)}
                    className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium rounded-lg border border-slate-700 transition-colors cursor-pointer flex items-center gap-1.5"
                  >
                    <BarChart3 className="w-3.5 h-3.5 text-cyan-400" />
                    <span>{showInlineHistogram ? "Hide Inline Histogram" : "Show Inline Histogram"}</span>
                  </button>
                  <button
                    onClick={() => {
                      setSelectedHistogramCamera("CAM_B");
                      setActiveTab("histogram");
                    }}
                    className="px-3 py-1.5 bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 text-xs font-medium rounded-lg border border-cyan-500/40 transition-colors cursor-pointer flex items-center gap-1.5"
                  >
                    <span>Full Spectrum Tab</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                </div>
              </div>

              {/* Expandable Inline Histogram when toggled inside evaluator */}
              {showInlineHistogram && (
                <CameraHistogram
                  selectedCameraId={selectedHistogramCamera}
                  onSelectCamera={setSelectedHistogramCamera}
                  vehicles={vehicles}
                  queryColorHex="#f0f2f5"
                  queryColorName="Arctic White"
                />
              )}

          {/* Interactive Fusion Weight Sliders */}
          <div className="bg-slate-950/90 border border-slate-800 p-4 rounded-xl">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                <Sliders className="w-4 h-4 text-cyan-400" />
                Bayesian Fusion Weights (Adjust in Real-Time):
              </span>
              <button
                onClick={() => {
                  setWeightApp(0.4);
                  setWeightSt(0.4);
                  setWeightMicro(0.2);
                }}
                className="text-[11px] text-cyan-400 hover:underline"
              >
                Reset to Optimal (40% App / 40% ST / 20% Micro)
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-slate-400">Visual Appearance (W_app):</span>
                  <span className="font-mono text-cyan-400 font-bold">{(weightApp * 100).toFixed(0)}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={weightApp}
                  onChange={(e) => setWeightApp(parseFloat(e.target.value))}
                  className="w-full accent-cyan-400 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-slate-400">Spatio-Temporal Plausibility (W_st):</span>
                  <span className="font-mono text-amber-400 font-bold">{(weightSt * 100).toFixed(0)}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={weightSt}
                  onChange={(e) => setWeightSt(parseFloat(e.target.value))}
                  className="w-full accent-amber-400 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-slate-400">Micro-Features (W_micro):</span>
                  <span className="font-mono text-emerald-400 font-bold">{(weightMicro * 100).toFixed(0)}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={weightMicro}
                  onChange={(e) => setWeightMicro(parseFloat(e.target.value))}
                  className="w-full accent-emerald-400 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
                />
              </div>
            </div>
          </div>

          {/* Candidates Evaluation Comparison Cards */}
          <div className="space-y-3">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              Camera 02 Downstream Candidates Evaluated
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {evaluated.map((c, idx) => {
                const isWinner = c.finalScore > 0.78;
                return (
                  <div
                    key={c.id}
                    className={`p-4 rounded-xl border transition-all ${
                      isWinner
                        ? "bg-emerald-950/20 border-emerald-500/80 shadow-lg shadow-emerald-950/40 ring-1 ring-emerald-500/50"
                        : "bg-slate-950/80 border-slate-800 opacity-90"
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-bold text-white">{c.name}</span>
                      {isWinner ? (
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center gap-1">
                          <CheckCircle className="w-3 h-3" /> MATCH CONFIRMED
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-500/20 text-rose-400 border border-rose-500/40 flex items-center gap-1">
                          <XCircle className="w-3 h-3" /> REJECTED
                        </span>
                      )}
                    </div>

                    <div className="text-xs text-slate-400 mb-3 flex items-center justify-between">
                      <span>Seen at: {c.timeB}</span>
                      <span className="font-mono font-bold text-cyan-300">Δt = {c.deltaT}s</span>
                    </div>

                    {/* Breakdown Bars */}
                    <div className="space-y-2 text-xs bg-slate-900/90 p-3 rounded-lg border border-slate-800 mb-3">
                      <div>
                        <div className="flex justify-between text-[11px] mb-0.5">
                          <span className="text-slate-400">Visual Similarity:</span>
                          <span className="font-mono font-bold text-cyan-400">
                            {(c.rawVisualSim * 100).toFixed(0)}%
                          </span>
                        </div>
                        <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                          <div
                            className="bg-cyan-400 h-full rounded-full"
                            style={{ width: `${c.rawVisualSim * 100}%` }}
                          />
                        </div>
                      </div>

                      <div>
                        <div className="flex justify-between text-[11px] mb-0.5">
                          <span className="text-slate-400">Spatio-Temporal Plausibility:</span>
                          <span
                            className={`font-mono font-bold ${
                              c.stScore > 0.6 ? "text-emerald-400" : "text-rose-400"
                            }`}
                          >
                            {(c.stScore * 100).toFixed(0)}% ({c.speedImplied} km/h)
                          </span>
                        </div>
                        <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                          <div
                            className={`h-full rounded-full ${c.stScore > 0.6 ? "bg-emerald-400" : "bg-rose-500"}`}
                            style={{ width: `${c.stScore * 100}%` }}
                          />
                        </div>
                      </div>

                      <div>
                        <div className="flex justify-between text-[11px] mb-0.5">
                          <span className="text-slate-400">Micro-Features Match:</span>
                          <span
                            className={`font-mono font-bold ${
                              c.microScore > 0.6 ? "text-emerald-400" : "text-amber-400"
                            }`}
                          >
                            {(c.microScore * 100).toFixed(0)}%
                          </span>
                        </div>
                        <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                          <div
                            className="bg-amber-400 h-full rounded-full"
                            style={{ width: `${c.microScore * 100}%` }}
                          />
                        </div>
                      </div>
                    </div>

                    {/* Final Composite Posterior Score */}
                    <div className="pt-2 border-t border-slate-800 flex items-center justify-between">
                      <span className="text-xs font-semibold text-slate-300">Composite Confidence:</span>
                      <span
                        className={`text-base font-mono font-bold ${
                          isWinner ? "text-emerald-400" : "text-slate-400"
                        }`}
                      >
                        {(c.finalScore * 100).toFixed(1)}%
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </>
      )}
    </div>

        {/* Footer with AI Deep Reasoning Action */}
        <div className="px-6 py-4 border-t border-slate-800 bg-slate-950/90 flex flex-wrap items-center justify-between gap-3">
          <div className="text-xs text-slate-400 flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Zero License Plate OCR required. Compliant with privacy regulations.</span>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() =>
                onRunAiAnalysis({
                  queryVehicle,
                  candidates,
                  spatioTemporalPrior: {
                    distanceMeters: 500,
                    expectedMeanSeconds: expectedTransitMean,
                    stdDevSeconds: transitStdDev,
                    congestionRegime: congestionLevel,
                  },
                })
              }
              disabled={isAiLoading}
              className="px-4 py-2 bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 text-white font-bold text-xs rounded-xl flex items-center gap-2 shadow-lg cursor-pointer disabled:opacity-50"
            >
              <Sparkles className="w-4 h-4 text-yellow-300" />
              <span>{isAiLoading ? "Analyzing via Gemini 4..." : "Audit with Gemini-4-Argon (High Thinking)"}</span>
            </button>

            <button
              onClick={onClose}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium text-xs rounded-xl transition-colors cursor-pointer"
            >
              Close Lab
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
