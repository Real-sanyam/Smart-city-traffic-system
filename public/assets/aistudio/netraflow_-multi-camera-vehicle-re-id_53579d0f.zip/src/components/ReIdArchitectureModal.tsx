import React, { useState } from "react";
import { X, BookOpen, Layers, Network, Clock, ShieldCheck, Sparkles, Send, CheckCircle2 } from "lucide-react";

interface ReIdArchitectureModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ReIdArchitectureModal: React.FC<ReIdArchitectureModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [selectedStep, setSelectedStep] = useState<number>(3);
  const [question, setQuestion] = useState("");
  const [aiAnswer, setAiAnswer] = useState<string | null>(null);
  const [isAsking, setIsAsking] = useState(false);

  if (!isOpen) return null;

  const steps = [
    {
      num: 1,
      title: "Single-Camera Detection & Tracking",
      subtitle: "YOLOv8/v10 + ByteTrack / BoT-SORT",
      summary:
        "Maintains persistent tracklets within each camera view despite dense occlusions from buses, autos, and two-wheelers.",
      details: [
        "Trained on Indian Mixed Traffic datasets (e.g. IDD - India Driving Dataset, Auto-Rickshaws, Scooters).",
        "ByteTrack uses two-stage matching: high-confidence detections first, then low-confidence detections to retain occluded vehicles without ID switches.",
        "Generates tracklet bounding boxes and smooth trajectory vectors over time.",
      ],
    },
    {
      num: 2,
      title: "Part-Based Appearance Embeddings",
      subtitle: "OSNet / Swin-ReID / ResNet-IBN (PCB)",
      summary:
        "Transforms raw pixel crops into dense 512-dimensional metric embedding vectors invariant to camera angles and illumination.",
      details: [
        "Part-based Convolutional Baseline (PCB): divides vehicle crop into horizontal segments (roof, cabin/windshield, bumper/wheels) to capture local cues.",
        "Omni-Scale Network (OSNet): simultaneously captures multi-scale features (wheel rim patterns vs full vehicle body silhouette).",
        "Trained with Circle Loss / Triplet Loss with hard negative mining to separate visually similar car models.",
      ],
    },
    {
      num: 3,
      title: "Disambiguating Identical Vehicles",
      subtitle: "Spatio-Temporal Bayesian Fusion + Micro-Cues",
      summary:
        "The critical step: when visual appearance alone is identical (0.90 similarity), travel time feasibility and micro-cues break the tie.",
      details: [
        "Spatio-Temporal Plausibility Window: Travel time between non-overlapping cameras follows a Gaussian or Gamma probability density P(Δt | distance, congestion). Discards physically impossible speeds.",
        "Directional & Lane Trajectory: If vehicle exits Camera 1 heading East, only downstream cameras along plausible road segments are queried.",
        "Micro-Attribute Keypoint Attention: Detects distinctive non-standard markers: roof luggage racks, bumper dents/scratches, FASTag toll stickers, and rider/pillion helmet colors.",
      ],
    },
    {
      num: 4,
      title: "Cross-Camera Global Graph Matching",
      subtitle: "Hungarian Algorithm & Min-Cost Max-Flow",
      summary:
        "Solves the multi-camera association problem as a bipartite matching graph to prevent double-counting.",
      details: [
        "Constructs cost matrix C_ij = -log(P(Match_ij)) between vehicles detected at Camera A and Camera B.",
        "Applies Kuhn-Munkres Hungarian Algorithm to compute the globally optimal 1-to-1 matching across camera pairs.",
        "Handles unobserved exits and entry ramps via dummy slack nodes in minimum cost network flow.",
      ],
    },
    {
      num: 5,
      title: "Traffic Flow & Origin-Destination Matrix",
      subtitle: "Municipal Planning & Corridor Intelligence",
      summary:
        "Aggregates validated cross-camera trips into Origin-Destination (OD) matrices to plan transit routes and roads.",
      details: [
        "Replaces expensive, biased manual roadside survey clipboards with automated 24/7 continuous flow data.",
        "Calculates dynamic OD matrices (Vehicles/hour from Junction A to Junction C).",
        "Identifies bottleneck bottlenecks, average corridor travel times, and modal split breakdowns.",
      ],
    },
  ];

  const handleAskQuickQuestion = async () => {
    if (!question.trim()) return;
    setIsAsking(true);
    setAiAnswer(null);
    try {
      const res = await fetch("/api/reid/fast-explain", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          stepName: steps[selectedStep - 1].title,
          technicalQuestion: question,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setAiAnswer(data.text);
      } else {
        setAiAnswer("Could not fetch answer: " + (data.error || "Unknown error"));
      }
    } catch (e: any) {
      setAiAnswer("Network error: " + e.message);
    } finally {
      setIsAsking(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 select-none">
      <div className="bg-slate-900 border border-slate-700 w-full max-w-4xl rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/80">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/30">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                Multi-Camera Vehicle Re-Identification Architecture
              </h2>
              <p className="text-xs text-slate-400">
                End-to-End System Blueprint: Detecting, Tracking, and Matching Vehicles Without Reading Number Plates
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-6">
          {/* Step Navigator Bar */}
          <div className="grid grid-cols-5 gap-2">
            {steps.map((s) => (
              <button
                key={s.num}
                onClick={() => {
                  setSelectedStep(s.num);
                  setAiAnswer(null);
                }}
                className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                  selectedStep === s.num
                    ? "bg-cyan-950/80 border-cyan-500 text-white shadow-md ring-1 ring-cyan-500"
                    : "bg-slate-950/60 border-slate-800 text-slate-400 hover:text-slate-200 hover:bg-slate-900"
                }`}
              >
                <div className="text-[10px] font-bold text-cyan-400 uppercase tracking-wider mb-0.5">
                  Step {s.num}
                </div>
                <div className="text-xs font-semibold truncate">{s.title}</div>
              </button>
            ))}
          </div>

          {/* Active Step Detailed Card */}
          {(() => {
            const step = steps[selectedStep - 1];
            return (
              <div className="bg-slate-950/90 border border-slate-800 rounded-2xl p-6 space-y-4">
                <div className="flex items-start justify-between">
                  <div>
                    <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/40">
                      Pipeline Phase {step.num} of 5
                    </span>
                    <h3 className="text-base font-bold text-white mt-1.5">{step.title}</h3>
                    <div className="text-xs text-cyan-400 font-mono">{step.subtitle}</div>
                  </div>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed bg-slate-900/80 p-3 rounded-xl border border-slate-800/80">
                  {step.summary}
                </p>

                <div className="space-y-2">
                  <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                    Engineering Deep-Dive & Methodological Details:
                  </h4>
                  <ul className="space-y-2">
                    {step.details.map((d, i) => (
                      <li key={i} className="text-xs text-slate-300 flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                        <span>{d}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            );
          })()}

          {/* Fast Gemini Explainer Interaction */}
          <div className="bg-slate-950/90 border border-slate-800 p-4 rounded-2xl">
            <div className="flex items-center gap-2 mb-2 text-xs font-bold text-slate-300">
              <Sparkles className="w-4 h-4 text-yellow-400" />
              <span>Ask Gemini 3.1 Flash-Lite about this pipeline step:</span>
            </div>
            <div className="flex gap-2">
              <input
                type="text"
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleAskQuickQuestion()}
                placeholder={`e.g. Why is ByteTrack preferred over DeepSORT in dense Indian mixed traffic?`}
                className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400"
              />
              <button
                onClick={handleAskQuickQuestion}
                disabled={isAsking || !question.trim()}
                className="px-4 py-2 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer disabled:opacity-50"
              >
                <Send className="w-3.5 h-3.5" />
                <span>{isAsking ? "Thinking..." : "Explain"}</span>
              </button>
            </div>

            {aiAnswer && (
              <div className="mt-3 p-3 bg-slate-900/90 border border-cyan-800/60 rounded-xl text-xs text-slate-200 leading-relaxed whitespace-pre-wrap">
                {aiAnswer}
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-800 bg-slate-950/80 flex items-center justify-between">
          <span className="text-[11px] text-slate-500">
            Complies with municipal privacy regulations and zero-license-plate camera standards.
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium rounded-xl transition-colors cursor-pointer"
          >
            Close Guide
          </button>
        </div>
      </div>
    </div>
  );
};
